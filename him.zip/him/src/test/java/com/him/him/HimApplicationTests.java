package com.him.him;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HimApplicationTests {

	@Test
	void contextLoads() {
	}

}
