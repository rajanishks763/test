package com.him.him;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HimApplication {

	public static void main(String[] args) {
		SpringApplication.run(HimApplication.class, args);
	}

}
